Free Site License:
------------------

CC 3.0 All of the site templates we create for WebThemez are licensed under the Creative Commons Attribution 4.0 License, which means you can:
 - You can use our templates for both personal and commercial projects. 
 - You are NOT allowed to remove the back link to WebThemez.com in templates unless you purchased a license. 
 - You can update /modify/customize the website to fit your project needs. 
 - You cannot claim credit or ownership for any of the files found on webthemez.com. 
 - You cannot redistribute, resell, license, or sub-license any of the files found on webthemez.com. 

 - No Support
 - No Php files ( contact form does not work)
 - No Updates


Credits :
--------- 

=> Design & developed: "WebThemez"  http://webthemez.com 
=> Bootstrap : http://getbootstrap.com/
=> Fontawesome : https://fortawesome.github.io/Font-Awesome/
=> Fonts : https://www.google.com/fonts
=> Images : https://unsplash.com/ , https://www.pexels.com/ and https://pixabay.com/
=> Carousel : http://owlgraphic.com/owlcarousel/
